# Portfolio

Welcome to my personal portfolio repository! This project showcases my skills, projects, and experiences as a web developer 

## Table of Contents

- Home
- About Me
- Projects
- Skils
- Contact

## About Me

Hello! I'm Jidan, a passionate Web Developer with a focus on frontend developer . I love solving problems, creating innovative solutions, and continuously learning new things. My goal is to deliver quality code and impactful projects.

## Contact

Feel free to reach out to me:

- **Email:** jidangamer7@gmail.com
- **LinkedIn:** https://www.linkedin.com/in/jidan-7ab1322a6?utm_source=share&utm_campaign=share_via&utm_content=profile&utm_medium=android_app
- **Website/Portfolio:** https://jidandev.github.io/portfolio/
